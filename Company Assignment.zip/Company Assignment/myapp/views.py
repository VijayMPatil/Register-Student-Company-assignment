from django.shortcuts import render
from myapp.Serializers import StudentSerializer
from rest_framework.response import Response
from myapp.models import Department, Student
from rest_framework import generics
from rest_framework import status
from rest_framework.renderers import JSONRenderer

# Create your views here.

class StudentAddAPI(generics.ListCreateAPIView):
    queryset = Student.objects.all()
    serializer_class = StudentSerializer
    
    def post(self, request, *args, **kwargs):
        dept_list = request.data.get('dept_id')
        
        stud_obj = Student(stud_id=request.data['stud_id'],first_name=request.data['first_name'],last_name=request.data['last_name'])
        stud_obj.save()

        for cr in dept_list:
            dept_obj=Department.objects.get(pk=cr['dept_id'])
            #print(dept_obj)
            stud_obj.departments.add(dept_obj)
        
        serializer = StudentSerializer(stud_obj)
        return Response(serializer.data) 


class StudentUpdateAPI(generics.RetrieveUpdateAPIView):
    queryset = Student.objects.all()
    serializer_class = StudentSerializer
    #authentication_classes = [CustomAdminAuthentication]

    def get(self, request, *args, **kwargs):
        obj = Student.objects.get(stud_id=self.request.query_params.get('stud_id'))
        serializer = StudentSerializer(obj)
        return Response(serializer.data)

    def put(self, request, *args, **kwargs):
        
        obj = Student.objects.get(stud_id=self.request.query_params.get('stud_id'))
        dept_list = request.data.get('dept_id')
        if "first_name" in request.data.keys():
            obj.first_name = request.data['first_name']

        if "last_name" in request.data.keys():
            obj.last_name= request.data['last_name']
        
        if "dept_id" in request.data.keys():
            for cr in dept_list:
                print(cr)
                dept_obj=Department.objects.get(pk=cr['dept_id'])
                print(dept_obj)
                obj.departments.remove(dept_obj)
        serializer = StudentSerializer(obj)
        return Response(serializer.data)     
    

class StudentDeleteView(generics.RetrieveDestroyAPIView):
    def destroy(self, request, *args, **kwargs):
    
        stud_obj = Student.objects.filter(stud_id=self.request.query_params.get('stud_id'))
        stud_obj.delete()
        response = Response({'sucess': 'Student information has been deleted..'}, status=status.HTTP_200_OK)
        response.accepted_renderer = JSONRenderer()
        response.accepted_media_type = "application/json"
        response.renderer_context = {}
        return response

      
class StudentListAPI(generics.ListAPIView):
    queryset= Student.objects.all()
    serializer_class = StudentSerializer
    
    def get(self, request, *args, **kwargs):
        students_obj = Student.objects.all()
        serializer = StudentSerializer(students_obj, many=True)
        return Response(serializer.data)