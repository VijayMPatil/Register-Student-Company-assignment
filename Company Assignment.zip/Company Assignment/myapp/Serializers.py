from dataclasses import fields
from pyexpat import model
from rest_framework import serializers
from .models import Student, Department


class DepartmentSerializer(serializers.ModelSerializer):
    class Meta:
        model=Department
        fields=['dept_id','dept_name','dept_head']


class StudentSerializer(serializers.ModelSerializer):
    departments = DepartmentSerializer(many=True)
    class Meta:
        model =Student
        fields=['stud_id','first_name','last_name','departments']